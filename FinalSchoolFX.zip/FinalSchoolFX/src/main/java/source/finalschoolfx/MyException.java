package source.finalschoolfx;

public class MyException extends Exception{
    public MyException(){
        super("Неправильно введены данные(");
    }
}
