package source.finalschoolfx.repository;

import source.finalschoolfx.models.Student;

public class StudentRepository extends BaseRepository<Student>{
    public StudentRepository(Student model) {
        super(model);
    }
}
