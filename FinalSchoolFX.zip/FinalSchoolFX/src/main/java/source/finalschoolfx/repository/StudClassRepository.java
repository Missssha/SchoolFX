package source.finalschoolfx.repository;

import source.finalschoolfx.models.StudClass;

public class StudClassRepository extends BaseRepository<StudClass>{
    public StudClassRepository(StudClass model) {
        super(model);
    }
}
