package source.finalschoolfx.repository;

import source.finalschoolfx.models.Teacher;

public class TeacherRepository extends BaseRepository<Teacher> {
    public TeacherRepository(Teacher model) {
        super(model);
    }
}
