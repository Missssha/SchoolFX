package source.finalschoolfx.repository;

import source.finalschoolfx.models.Discipline;

public class DisciplineRepository extends BaseRepository<Discipline> {
    public DisciplineRepository(Discipline model) {
        super(model);
    }
}
